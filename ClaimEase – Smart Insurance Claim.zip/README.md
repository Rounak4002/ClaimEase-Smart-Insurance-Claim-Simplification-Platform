
# ClaimEase – Smart Insurance Claim Simplification Platform

## Description
ClaimEase is a fresher-friendly full-stack insurance claim system designed to simplify claim submission and tracking for customers and operations teams.

## Features
- Submit insurance claims
- View all submitted claims
- Simple frontend interface
- REST API backend

## Tech Stack
- Backend: Python (FastAPI)
- Frontend: HTML + JavaScript
- Database: SQLite

## How to Run
1. Install dependencies:
   pip install -r backend/requirements.txt
2. Start server:
   uvicorn backend.app.main:app --reload
3. Open frontend/index.html in browser
